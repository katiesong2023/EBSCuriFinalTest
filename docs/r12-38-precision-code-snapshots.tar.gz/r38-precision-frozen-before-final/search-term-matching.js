// 한글에는 JS의 \b를 쓸 수 없다. 다른 단어의 안쪽 일치 대신
// 독립 표현, 조사/활용형, 명시적으로 확인한 복합어만 허용한다.
const compounds = {
 연소: ['완전연소','불완전연소','연소반응','연소과정','연소실험','연소조건','연소생성물'],
 김제: ['김제평야'], 산소: ['산소농도','산소량'], 이산화탄소: ['이산화탄소농도'],
 선거: ['선거권','선거제도','선거운동'], 투표: ['투표권','투표용지','투표소'],
 산화: ['산화물','산화반응','산화작용'], 자전: ['자전축','자전주기'], 공전: ['공전궤도','공전주기'],
 영양: ['영양소','영양사','영양분','영양섭취','영양결핍'],
 기술: ['과학기술','적정기술','첨단기술','정보기술','기술자','기술력','해동기술','저장기술'],
 무역: ['자유무역','공정무역','무역로','무역회사','무역영어'],
 생산: ['생산자','생산량','생산성','생산현장','재생산','대량생산','식량생산','노동생산성'],
 소비: ['소비자','과소비','소비기한','소비습관','소비처'],
 음악: ['음악회','음악대','음악치료','전통음악'], 택배: ['택배원','택배놀이','우체국택배원']
};
const particles = '(?:에서|에게서|한테서|으로부터|로부터|에게|한테|으로|처럼|보다|까지|부터|마다|조차|밖에|뿐|의|을|를|은|는|이|가|와|과|에|로|도|만|들)';
const endings = '(?:하다|한다|하는|하고|하며|하면|하여|하기|한|할|했다|했던|해요|해내는|합니다|된다|되는|되고|되어|되었다|되면|되기|시키다|시키는|이다|이었다|입니다|인|이고|이며|이라는|이란)';
const escape = value => value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const cache = new Map();
function expressionPattern(expression) {
 const value = String(expression || '').normalize('NFKC').trim();
 if (!value) return null;
 if (!cache.has(value)) {
  const word = escape(value).replace(/\s+/g,'\\s*');
  const suffix = /[가-힣]$/u.test(value) ? `(?:${particles}){0,3}(?:${endings})?` : /[a-z]$/iu.test(value) ? '(?:s|es)?' : '';
  cache.set(value,new RegExp(`(?<![\\p{L}\\p{N}])${word}${suffix}(?![\\p{L}\\p{N}])`,'iu'));
 }
 return cache.get(value);
}
function matchingTerms(term,text,aliases=[]) {
 const source = String(text || '').normalize('NFKC');
 return [...new Set([term,...aliases,...(compounds[term] || [])])].filter(word=>expressionPattern(word)?.test(source));
}
module.exports = { matchingTerms, expressionPattern, compounds };
