const { matchingLiteralExpressions: matchingExpressions, literalSource } = require('./source-literal');
const { softRelationTerm } = require('./natural-request');
const { assessSourceText } = require('./source-text-quality');
const { searchableSupplements } = require('./supplement-search');

// 주제와 설명 단서가 같은 문장에 있는지를 순위에만 반영한다. 의미 충족 판정은 아니다.
const relations = [
  { label: '역할·하는 일', query: /역할|하는\s*일|기능/u, cue: /역할|기능|제공|도움|돕|도와|빌리|빌려|대출|서비스|담당|지원/u },
  { label: '변화·과정', query: /바뀐|바뀌|달라진|변화|변천/u, cue: /바뀌|바뀐|달라|변화|변천|사라|생겨|생기|변모|과거|예전/u },
  { label: '원인·결과', query: /까닭|원인|이유|때문/u, cue: /때문|인해|원인|결과|영향|따라서|그래서/u },
  { label: '필요 조건', query: /필요한\s*조건|타려면|타는\s*조건/u, cue: /조건|필요|산소|발화점/u }
];
function requestRelevance(item, request, sentences) {
  const original = request.naturalLanguage?.original || request.positiveQuery || '';
  const groups = [
    ...(request.concepts || []).map(c => c.requestedAliases?.length ? c.requestedAliases : c.aliases || [c.label]),
    ...(request.terms || []).filter(t => !softRelationTerm(t)).map(t => [t]),
    ...(request.alternativeGroups || []).flatMap(group => group.map(option => [option.text, ...(option.terms || [])].filter(Boolean)))
  ];
  const hits = text => groups.filter(aliases => aliases.some(alias => matchingExpressions(alias, text).length)).length;
  const requested = relations.filter(r => r.query.test(original));
  const quality = assessSourceText(item.title, item.summary);
  const summaryAvailable = !['none', 'repeated', 'production'].includes(quality.category);
  const sources = [
    ...(summaryAvailable ? sentences : []),
    ...searchableSupplements(item).flatMap(s => require('./source-explanation').sourceSentences(s.text, 'sourceSupplement')
      .map(sentence => ({ ...sentence, supplementId: s.id, sourceUrl: s.sourceUrl })))
  ];
  const relationQuotes = [...(item.contentRelation?.evidence || []), ...(item.requestRelation?.evidence || [])];
  const scored = sources.map(sentence => {
    const topics = hits(sentence.quote);
    const question = /[?？]$/u.test(sentence.quote.trim());
    const cues = topics && !question ? requested.filter(r => r.cue.test(sentence.quote)).length : 0;
    const knownRelation = relationQuotes.some(q => q.field === sentence.field && q.start === sentence.start && q.end === sentence.end && q.quote === sentence.quote && q.supplementId === sentence.supplementId);
    return { sentence, topics, cues, score: topics * 4 + cues * 12 + (knownRelation ? 16 : 0) - (question ? 8 : 0) };
  }).filter(row => row.topics || row.score > 0).sort((a, b) => b.score - a.score || a.sentence.start - b.sentence.start);
  const details = requested.map(r => ({ label: r.label, status: 'UNKNOWN', evidence: scored.filter(row => row.topics && !/[?？]$/u.test(row.sentence.quote.trim()) && r.cue.test(row.sentence.quote)).slice(0, 2).map(row => row.sentence) }));
  for (const detail of details) if (detail.evidence.length) detail.status = 'RELATION_WORDING_CUE';
  const best = scored[0];
  return {
    method: 'LOCAL_SENTENCE_CUES', score: groups.length && best && (!requested.length || best.cues || relationQuotes.length) ? Math.min(48, 12 + (hits(literalSource(item).title) ? 8 : 0) + (best?.topics > 1 ? 8 : 0) + (best?.cues || relationQuotes.length ? 20 : 0)) : 0,
    topicEvidence: scored.filter(row => row.sentence.field === 'summary').slice(0, 3).map(row => row.sentence),
    supplementEvidence: scored.filter(row => row.sentence.field === 'sourceSupplement').slice(0, 3).map(row => row.sentence),
    details, note: '같은 문장의 주제·설명 표현을 비교한 로컬 순위입니다. 의미 충족·영상 적합성은 미확인입니다.'
  };
}
module.exports = { requestRelevance };
