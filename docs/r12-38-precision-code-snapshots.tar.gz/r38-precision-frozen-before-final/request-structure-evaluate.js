// 기존 200/170 원문을 실제 교사 검색으로 재실행한다. 입력의 기대 주제/유형은 주입하지 않는다.
const fs = require('node:fs/promises');
const crypto = require('node:crypto');
const { discoverTeacherContents } = require('./teacher-discovery');
const { loadDiscoveryCatalog } = require('./discovery-catalog');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
async function main() {
  const output = 'docs/r12-39-existing370.json';
  try { await fs.access(output); throw Error('고정 결과를 덮어쓸 수 없습니다.'); } catch(e) { if(e.code !== 'ENOENT') throw e; }
  const inputPaths = ['docs/r12-search-test-200-input.json','docs/r12-03-common-stable170.json'];
  const inputs = await Promise.all(inputPaths.map(async p => {const b=await fs.readFile(p);return {path:p,sha256:sha(b),data:JSON.parse(b)};}));
  const rows = [...inputs[0].data.rows.map(r=>({...r,set:'new200'})),...inputs[1].data.rows.map(r=>({...r.request,set:'previous170'}))];
  const paths = ['server/data/broadcast-catalog.sqlite','server/data/semantic-layer.sqlite','server/data/automatic-assets.sqlite','server/data/broadcast-semantic-search.sqlite','server/data/curi-store.json',...(await fs.readdir('server')).filter(n=>n.endsWith('.js')).map(n=>'server/'+n)];
  const hashes = async () => Object.fromEntries(await Promise.all(paths.map(async p=>[p,sha(await fs.readFile(p))])));
  const before = await hashes(), startedAt = new Date().toISOString(), catalog = await loadDiscoveryCatalog(), results = [];
  for (const request of rows) {
    try {
      const api = await discoverTeacherContents({q:request.query,workspace:'teacher'},catalog);
      results.push({set:request.set,id:request.id,query:request.query,total:api.total,terms:api.terms,projection:api.understanding.requestProjection,emptyReason:api.emptyReason,
        top5:api.results.slice(0,5).map(r=>({id:r.id,title:r.title,program:r.program,summary:r.summary,sourceUrl:r.sourceUrl,searchExplanation:r.searchExplanation}))});
    } catch(e) {results.push({set:request.set,id:request.id,query:request.query,error:e.message});}
    if(results.length%20===0) console.log(results.length+'/370');
  }
  const reproduction = [];
  for(const q of ['자본주의','자본주의 초등학생 교육용 자료','초등학생 교육용 자료']) {const r=await discoverTeacherContents({q},catalog);reproduction.push({query:q,total:r.total,terms:r.terms,emptyReason:r.emptyReason,topIds:r.results.map(x=>x.id),projection:r.understanding.requestProjection});}
  const after = await hashes();
  const counts = Object.fromEntries(['new200','previous170'].map(set=>{const r=results.filter(x=>x.set===set);return [set,{inputs:r.length,nonempty:r.filter(x=>x.total>0).length,empty:r.filter(x=>x.total===0).length,errors:r.filter(x=>x.error).length}];}));
  const report = {startedAt,finishedAt:new Date().toISOString(),inputHashes:inputs.map(({path,sha256})=>({path,sha256})),sourceCatalogCount:catalog.resources.length,counts,reproduction,
    before,after,changedFiles:paths.filter(p=>before[p]!==after[p]),paidApiCalls:0,scope:'既存370原文のローカル教員検索実行。結果有無は正答率ではない。新しい成功例セットを追加せず、元の入力は固定。',rows:results};
  report.scope='기존370 원문으로 실제 교사 검색 내부 함수 실행. 건수는 정답률이 아니며 영상·학년 적합성은 미검증. 새 성공 표본 추가 없이 원래 입력 고정. 과거 실행과 엔진/원천 판본이 달라 직접 개선율을 계산하지 않음.';
  await fs.writeFile(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({counts,reproduction,changedFiles:report.changedFiles}));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
