const { vocabulary } = require('./keyword-vocabulary');
const { concepts } = require('./semantic-layer');
const { isMeaningNoun } = require('./source-meaning');
const { specificTerms } = require('./content-preview');
const { unitAnchors } = require('./curriculum-expansion-anchors');
const { additionalTerms } = require('./content-keywords');
// 내용 추출과 검색은 같은 원천 어휘를 사용한다. 낯선 명사의 끝 글자를 조사로 추측하지 않는다.
const nouns = new Set([...vocabulary, ...additionalTerms, ...specificTerms, ...Object.values(unitAnchors).flat(), ...concepts.flatMap(c => c.aliases)]);
const catalogWords = new WeakMap();
function sourceVocabulary(resources) {
  if (!catalogWords.has(resources)) catalogWords.set(resources, new Set(resources.flatMap(item =>
    `${item.title || ''} ${item.summary || ''}`.normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}]+/gu) || [])));
  return catalogWords.get(resources);
}
function normalizeRequestNoun(term, sourceWords, isGrammar = () => false) {
  const known = value => nouns.has(value) || isMeaningNoun(value);
  if (known(term)) return term;
  // 여러 음절의 명시적 격 표지는 미등록 고유명에도 붙는다. 한 글자 끝음절 추측과 구분한다.
  const explicit = term.replace(/(?:에서는|에서|으로|처럼|에게|한테)$/u, '');
  if (explicit !== term && explicit.length > 1) return explicit;
  const base = term.replace(/(?:들)?(?:에서는|에서|으로|처럼|에게|한테|의|을|를|은|는|이|가|와|과|에|로)$/u, '');
  if (base !== term && (known(base) || isGrammar(base))) return base;
  if (sourceWords?.has(term)) return term;
  return base !== term && sourceWords?.has(base) ? base : term;
}
module.exports = { normalizeRequestNoun, sourceVocabulary };
