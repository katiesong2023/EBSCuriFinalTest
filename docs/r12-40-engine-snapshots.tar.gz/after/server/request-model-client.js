// 외부 실행은 기본 차단이다. 준비 경로에서는 이 클라이언트를 호출하지 않는다.
function createRequestModelClient({ allowExternal = false, model, maxCalls = 0, maxOutputTokens = 4096, timeoutMs = 12000, approvedBudgetUsd = 0 } = {}) {
  let calls = 0;
  return {
    async respond(prepared) {
      if (!allowExternal || process.env.CURI_ALLOW_PAID_API !== 'true') throw new Error('MODEL_CALL_DISABLED');
      if (!Number.isInteger(maxCalls) || maxCalls <= calls || !Number.isFinite(approvedBudgetUsd) || approvedBudgetUsd <= 0 || !model) throw new Error('MODEL_EXECUTION_SCOPE_REQUIRED');
      // 예산은 승인 범위 기록이다. 금액 실측/공급자 지출 상한 연결 전에는 제품에서 활성화하지 않는다.
      if (!Number.isInteger(maxOutputTokens) || maxOutputTokens < 1 || maxOutputTokens > 4096 || !Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 30000 || !prepared?.payload) throw new Error('MODEL_EXECUTION_LIMIT_INVALID');
      const key = process.env.OPENAI_API_KEY;
      if (!key) throw new Error('MODEL_CREDENTIAL_REQUIRED');
      calls++;
      const response = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST', signal: AbortSignal.timeout(timeoutMs),
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({ ...prepared.payload, model, max_output_tokens: maxOutputTokens })
      });
      if (!response.ok) throw new Error('MODEL_PROVIDER_ERROR');
      return response.json();
    },
    get attemptedCalls() { return calls; }
  };
}
module.exports = { createRequestModelClient };
