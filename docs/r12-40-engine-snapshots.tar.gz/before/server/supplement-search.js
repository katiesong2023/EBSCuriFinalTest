// 소개문과 분리하여 회차·판본·해시를 대조한 공식 보조 원문만 검색에 사용한다.
const {validSupplement}=require('./source-supplements');
function searchableSupplements(item){
 const identity={resourceId:item.id,title:item.title,program:item.program,broadcastDate:item.broadcastDate,variant:item.variant,sourceUrl:item.sourceUrl};
 return (item.sourceSupplements||[]).filter(record=>validSupplement(record,identity));
}
const supplementText=item=>searchableSupplements(item).map(record=>record.text).join('\n');
module.exports={searchableSupplements,supplementText};
